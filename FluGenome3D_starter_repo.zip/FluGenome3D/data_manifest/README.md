# Data manifest

This repository is designed to support two modes:

1. **Local full mode**: uses locally available non-redistributable Influenza A HA/NA data, for example GISAID-backed thesis datasets. Raw FASTA and metadata must not be committed.
2. **Public demo mode**: uses a small redistributable demo dataset or scripts/instructions for NCBI Datasets/NCBI Virus.

Only scripts, derived non-sensitive tables, aggregate figures, documentation, and reproducibility metadata should be committed.
