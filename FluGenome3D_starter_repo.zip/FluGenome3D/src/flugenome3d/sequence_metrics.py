from __future__ import annotations

from collections import Counter
from math import log2
from typing import Iterable

import numpy as np
import pandas as pd
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord

DNA_ALPHABET = set("ACGTUacgtu")
AMBIGUOUS = set("NRYKMSWBDHVnrykmswbdhv-")


def normalize_rna_to_dna(seq: str) -> str:
    return seq.upper().replace("U", "T")


def ambiguous_fraction(seq: str) -> float:
    s = seq.upper()
    if not s:
        return 1.0
    return sum(1 for ch in s if ch not in {"A", "C", "G", "T", "U"}) / len(s)


def gc_fraction(seq: str) -> float:
    s = normalize_rna_to_dna(seq)
    valid = [ch for ch in s if ch in "ACGT"]
    if not valid:
        return np.nan
    return (valid.count("G") + valid.count("C")) / len(valid)


def dinucleotide_counts(seq: str) -> Counter[str]:
    s = normalize_rna_to_dna(seq)
    return Counter(s[i : i + 2] for i in range(len(s) - 1) if set(s[i : i + 2]) <= set("ACGT"))


def mono_counts(seq: str) -> Counter[str]:
    s = normalize_rna_to_dna(seq)
    return Counter(ch for ch in s if ch in "ACGT")


def dinucleotide_odds_ratio(seq: str, dinuc: str) -> float:
    s = normalize_rna_to_dna(seq)
    n = len([ch for ch in s if ch in "ACGT"])
    if n < 2:
        return np.nan
    mono = mono_counts(s)
    di = dinucleotide_counts(s)
    x, y = dinuc.upper().replace("U", "T")
    expected = (mono[x] * mono[y]) / max(n, 1)
    observed = di[x + y]
    return observed / expected if expected else np.nan


def kmer_counts(seq: str, k: int, step: int = 1) -> Counter[str]:
    s = normalize_rna_to_dna(seq)
    return Counter(
        s[i : i + k]
        for i in range(0, len(s) - k + 1, step)
        if set(s[i : i + k]) <= set("ACGT")
    )


def shannon_entropy(counts: Counter[str]) -> float:
    total = sum(counts.values())
    if total == 0:
        return np.nan
    probs = [v / total for v in counts.values() if v > 0]
    return -sum(p * log2(p) for p in probs)


def sequence_record_metrics(records: Iterable[SeqRecord]) -> pd.DataFrame:
    rows = []
    for rec in records:
        seq = str(rec.seq)
        rows.append(
            {
                "seq_id": rec.id,
                "description": rec.description,
                "length": len(seq),
                "ambiguous_fraction": ambiguous_fraction(seq),
                "gc_fraction": gc_fraction(seq),
                "cpg_oe": dinucleotide_odds_ratio(seq, "CG"),
                "upa_oe": dinucleotide_odds_ratio(seq, "TA"),
                "k3_entropy": shannon_entropy(kmer_counts(seq, 3)),
                "k6_entropy": shannon_entropy(kmer_counts(seq, 6)),
            }
        )
    return pd.DataFrame(rows)


def translate_qc(seq: str) -> dict[str, object]:
    s = normalize_rna_to_dna(seq)
    trimmed = s[: len(s) - (len(s) % 3)]
    if not trimmed:
        return {"aa_length": 0, "internal_stop_count": np.nan, "terminal_stop": False}
    aa = str(Seq(trimmed).translate(to_stop=False))
    internal = aa[:-1].count("*") if len(aa) > 1 else 0
    return {"aa_length": len(aa), "internal_stop_count": internal, "terminal_stop": aa.endswith("*")}
