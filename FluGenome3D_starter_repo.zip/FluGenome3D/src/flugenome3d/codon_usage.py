from __future__ import annotations

from collections import Counter, defaultdict

import numpy as np
import pandas as pd
from Bio.Data import CodonTable

from .sequence_metrics import normalize_rna_to_dna

STANDARD_TABLE = CodonTable.unambiguous_dna_by_id[1]
CODON_TO_AA = {**STANDARD_TABLE.forward_table, **{codon: "*" for codon in STANDARD_TABLE.stop_codons}}
AA_TO_CODONS: dict[str, list[str]] = defaultdict(list)
for codon, aa in CODON_TO_AA.items():
    AA_TO_CODONS[aa].append(codon)


def codon_counts(seq: str) -> Counter[str]:
    s = normalize_rna_to_dna(seq)
    n = len(s) - (len(s) % 3)
    return Counter(s[i : i + 3] for i in range(0, n, 3) if set(s[i : i + 3]) <= set("ACGT"))


def rscu(seq: str) -> dict[str, float]:
    counts = codon_counts(seq)
    values: dict[str, float] = {}
    for aa, codons in AA_TO_CODONS.items():
        total = sum(counts[c] for c in codons)
        expected = total / len(codons) if codons else 0
        for codon in codons:
            values[codon] = counts[codon] / expected if expected else np.nan
    return values


def codon_usage_table(records) -> pd.DataFrame:
    rows = []
    for rec in records:
        counts = codon_counts(str(rec.seq))
        total = sum(counts.values())
        row = {"seq_id": rec.id, "codon_total": total}
        for codon in sorted(CODON_TO_AA):
            row[f"codon_{codon}"] = counts[codon]
            row[f"codon_freq_{codon}"] = counts[codon] / total if total else np.nan
        rows.append(row)
    return pd.DataFrame(rows)


def rscu_table(records) -> pd.DataFrame:
    rows = []
    for rec in records:
        row = {"seq_id": rec.id}
        row.update({f"rscu_{codon}": val for codon, val in rscu(str(rec.seq)).items()})
        rows.append(row)
    return pd.DataFrame(rows)
