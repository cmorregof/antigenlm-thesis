from flugenome3d.sequence_metrics import ambiguous_fraction, gc_fraction, dinucleotide_odds_ratio, kmer_counts


def test_gc_fraction():
    assert gc_fraction("ACGT") == 0.5


def test_ambiguous_fraction():
    assert ambiguous_fraction("ACGTNN") == 2 / 6


def test_kmer_counts():
    counts = kmer_counts("ACGTAC", 3)
    assert counts["ACG"] == 1
    assert counts["CGT"] == 1


def test_dinucleotide_odds_ratio_runs():
    val = dinucleotide_odds_ratio("ACGTCGTA", "CG")
    assert val >= 0
