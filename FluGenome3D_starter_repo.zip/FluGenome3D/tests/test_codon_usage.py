from flugenome3d.codon_usage import codon_counts, rscu


def test_codon_counts():
    counts = codon_counts("ATGATGTAA")
    assert counts["ATG"] == 2
    assert counts["TAA"] == 1


def test_rscu_contains_atg():
    vals = rscu("ATGATGTAA")
    assert "ATG" in vals
