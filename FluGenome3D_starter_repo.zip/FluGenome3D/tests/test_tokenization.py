from flugenome3d.tokenization import codon_tokenize, fixed_kmer_tokenize, crosses_codon_boundary


def test_codon_tokenize():
    toks = codon_tokenize("ATGAAA")
    assert toks == [("ATG", 0, 3), ("AAA", 3, 6)]


def test_fixed_kmer_tokenize():
    toks = fixed_kmer_tokenize("ATGAAA", k=3, step=1)
    assert len(toks) == 4


def test_crosses_codon_boundary():
    assert crosses_codon_boundary(1, 4) is True
    assert crosses_codon_boundary(0, 3) is False
