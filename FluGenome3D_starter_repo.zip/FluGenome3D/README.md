# FluGenome3D

**A reproducible sequence-context and structure-aware explorer for Influenza A HA/NA.**

FluGenome3D is a small scientific software project connected to AntigenSDE. It audits public or locally available Influenza A HA/NA sequences through sequence-context metrics, codon usage, dinucleotide bias, tokenizer-dependent representations inspired by DNA language models such as GROVER, and lightweight structure-aware visualization on representative HA/NA PDB structures.

## Scope

This repository is a **descriptive audit**, not a predictive or generative viral design tool.

It supports two modes:

1. **Local full mode**: uses local non-redistributable Influenza A HA/NA data, for example GISAID-backed thesis datasets. Raw FASTA/metadata must not be committed.
2. **Public demo mode**: uses small redistributable examples or documented NCBI Datasets instructions.

## What this project does

- Data inventory and schema discovery.
- HA/NA sequence filtering and QC.
- GC, CpG, UpA and dinucleotide odds ratios.
- k-mer frequencies, codon usage and RSCU.
- Lightweight tokenization audit: codons, fixed k-mers, optional exploratory BPE.
- Minimal structure visualization using representative HA/NA PDB/mmCIF files.

## What this project does not do

- No transformer training.
- No heavy fine-tuning.
- No viral sequence generation.
- No codon optimization.
- No vaccine prediction.
- No antigenic drift prediction.
- No escape, fitness, transmissibility or pathogenicity prediction.
- No claim that GROVER “understands” Influenza A.

## Setup

```bash
conda env create -f environment.yml
conda activate flugenome3d
pip install -e .
```

Or with pip:

```bash
pip install -e .
```

## Local full mode

Copy the example config:

```bash
cp config/local_paths.example.yml config/local_paths.yml
```

Edit `config/local_paths.yml` so that `local_data_roots` points to your local GISAID/AntigenLM/Influenza data folder.

Then run:

```bash
make inventory CONFIG=config/local_paths.yml
make build CONFIG=config/local_paths.yml
make metrics
make tokenization
make structure
```

## Expected MVP outputs

- `results/tables/data_inventory.csv`
- `data/processed/ha_na_metadata.parquet` *(local, gitignored if derived from GISAID)*
- `data/processed/ha_na_sequences.fasta` *(local, gitignored if derived from GISAID)*
- `results/tables/dataset_summary.csv`
- `results/tables/sequence_metrics.csv`
- `results/tables/codon_usage.csv`
- `results/tables/rscu.csv`
- `results/tables/tokenization_metrics.csv`
- `results/figures/*.png`
- `results/structures/*_demo.html`

## Representative structures

The starter config includes:

- HA H1N1: `3LZG`
- HA H3N2: `3VUN`
- NA N1: `3NSS`
- NA N2: `6BR6`

The first structure demo is intentionally minimal. Residue-level metric mapping should be added only after sequence-to-structure alignment has been checked carefully.

## Data governance

Raw GISAID-derived data, private metadata, accession-level tables with restricted redistribution, and local thesis datasets must not be committed. Keep them under `data/raw`, `data/interim`, or `data/processed`, which are gitignored by default.

## CV bullet

> Developed FluGenome3D, a reproducible Python workflow for Influenza A HA/NA sequence-context auditing, combining codon usage, CpG/UpA dinucleotide bias, tokenizer-dependent representation analysis inspired by DNA language models, and lightweight structure-aware visualization on representative PDB structures.

## Contact sentence

> In parallel to my AntigenSDE thesis, I am building FluGenome3D, a small reproducible audit of Influenza A HA/NA sequence context and tokenizer behavior inspired by GROVER, with modest structure-aware visualizations rather than predictive or generative claims.
